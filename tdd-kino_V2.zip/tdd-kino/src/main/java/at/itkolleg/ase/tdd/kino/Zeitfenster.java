package at.itkolleg.ase.tdd.kino;

public enum Zeitfenster {
    NACHMITTAG, ABEND, NACHT;
}
